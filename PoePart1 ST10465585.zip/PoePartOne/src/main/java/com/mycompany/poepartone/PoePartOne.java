/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poepartone;

/**
 *
 * @author RC_Student_lab
 */
import java.util.Scanner;

public class PoePartOne {

    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
         Login reg = new Login();
       
       System.out.print("\n=== User Login ===");
       
       // === User Registration ===
       System.out.print(" Enter your Username: ");
       String username = input.next();
       reg.setUserName(username);
       
       
       
       System.out.print(" Enter your password: ");
       String password = input.next();
       reg.setUserLast( password);
       
       
       System.out.print(" Enter your cell phone number: ");
       String phone = input.next();
       reg.setCellPhone( phone);
       
       
       
       // Set Registration Information
       
       // Validate phone, username, and password
       
       
       
       // === Proceed to Login if registration is successful ===
       if (reg.checkUsername() && reg.checkPasswordComplexity()) {
           System.out.println(" Password and Username correctly formatted ");
       }else{
           System.out.println(" Password and Username incorrectly formatted ");
       }
       
       
       System.out.println(" ===================LOGIN=================== ");
       
       
       System.out.print(" Enter your username ");
       String loginUser = input.next();
       reg.setUser( loginUser);
       
       
       System.out.print(" Enter your password ");
       String loginPass = input.next();
       reg.setPass( loginPass);
       
       if(reg.loginUser()){
           System.out.println(" Successfully Login ");
       }else{
           System.out.println(" Unsuccessfully Logged In ");
       }
       
       
    }
}
