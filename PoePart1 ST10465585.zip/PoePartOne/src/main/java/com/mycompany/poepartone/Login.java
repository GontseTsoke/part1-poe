/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poepartone;

/**
 *
 * @author RC_Student_lab
 */
class Login {
 
    
    // Fields to store user credentials and personal info
    private String User;
    private String Pass;
    private String userName;
    private String userLast;
    private String cellPhone;
    
    // Setters for registration details
    
    public String getUser() {
        return User;
    }
    
    public String getPass() {
        return Pass;
    }
    
    public String getUserName() {
        return userName;
    }
    
    public String getUserLast() {
        return userLast;
    }
    
    public String getcellPhone() {
        return cellPhone;
    }
    
    
    public void setUser(String User) {
        this.User = User;
    }
    
    public void setPass(String Pass) {
        this.Pass = Pass;
    }
    
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public void setUserLast(String userLast) {
        this.userLast = userLast;
    }
    
    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }
    
    
    
    // Method to check if the username is valid (max 5 characters and contains "_")
    public boolean checkUsername() {
        return userName.length() <= 5 && userName.contains("_");
    }
    
    // Method to check password complexity (must have uppercase, number, and speacial characters)
    public boolean checkPasswordComplexity() {
        boolean hasNumber = false, hasSpecial = false, hasUpper = false;
        
        if(userLast.length() >= 8) {
            for (char ch : userLast.toCharArray()) {
                if (Character.isUpperCase(ch)) {
                    hasUpper = true;
                } else if (Character.isDigit(ch)) {
                    hasNumber = true;
                }else if (!Character.isLetter(ch)) {
                    hasSpecial = true;
            }
            }
        }
        return hasUpper && hasNumber && hasSpecial;
    }
    
    
    
    // Method to validate phone number format (must include international code)
    public boolean checkcellPhone() {
        if (cellPhone.matches("\\+\\d(1,3)\\d(10)")) {
            System.out.println(" Cell Phone number successfully added.");
            return true;
        }else{
            System.out.println(" Cell Phone number incorrectly formatted or does not contain international code.");
            return false;
        } 
        }
        // Method to attempt user Registration and display feedback
    public String registerUser() {
        if (checkUsername()) {
            System.out.println("Username successfully captured");
       }else{
            System.out.println("Username is not correctly formatted, please ensure that your Username contains an Uppercase or underscore");
        }
        if (checkPasswordComplexity()) {
                  System.out.println("password successfully captured");
       }else{
                  System.out.println("password is not correctly formatted, please ensurethat the password contains at least of special characters");
              }
        if (checkUsername() && checkPasswordComplexity()) {
            System.out.println(" Thetwo above conditions have been met, and the user has been registered successfully ");
        }
              
         return "";     
        }
    
        //method to verify if login credentials match
        public boolean loginUser() {
        return userName.equals(User) && userLast.equals(Pass);
    
        }
    
        // Method to return login statue and welcome message
    public String returnLoginStatus() {
        if (loginUser()) {
            System.out.println("Successful Login");
            System.out.println("Welcome" + userName + "" + userLast + ". It is great to see you again.");
       }else{
            System.out.println(" A failed Login");
            System.out.println("Username, Password, or phone Number incorrect, please try again ");
        }
        return "";
    }
    }



