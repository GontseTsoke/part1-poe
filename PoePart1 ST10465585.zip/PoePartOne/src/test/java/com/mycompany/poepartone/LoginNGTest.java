/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package com.mycompany.poepartone;

import static org.testng.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class LoginNGTest {
    
    public LoginNGTest() {
    }

    

    /**
     * Test of getUser method, of class Login.
     */
   @org.testng.annotations.Test
public void testSetUser() {
    System.out.println("setUser");
    String expectedUser = "NewUser";
    Login instance = new Login();
    instance.setUser(expectedUser);
    assertEquals(instance.getUser(), expectedUser, "setUser failed");
}

@org.testng.annotations.Test
public void testSetPass() {
    System.out.println("setPass");
    String expectedPass = "SecurePass123!";
    Login instance = new Login();
    instance.setPass(expectedPass);
    assertEquals(instance.getPass(), expectedPass, "setPass failed");
}

@org.testng.annotations.Test
public void testSetUserName() {
    System.out.println("setUserName");
    String expectedUserName = "Test_User";
    Login instance = new Login();
    instance.setUserName(expectedUserName);
    assertEquals(instance.getUserName(), expectedUserName, "setUserName failed");
}

@org.testng.annotations.Test
public void testSetUserLast() {
    System.out.println("setUserLast");
    String expectedUserLast = "Last_Name";
    Login instance = new Login();
    instance.setUserLast(expectedUserLast);
    assertEquals(instance.getUserLast(), expectedUserLast, "setUserLast failed");
}

@org.testng.annotations.Test
public void testSetCellPhone() {
    System.out.println("setCellPhone");
    String expectedCellPhone = "+27821234567";
    Login instance = new Login();
    instance.setCellPhone(expectedCellPhone);
    assertEquals(instance.getcellPhone(), expectedCellPhone, "setCellPhone failed");
}

@org.testng.annotations.Test
public void testCheckUsername_valid() {
    System.out.println("checkUsername_valid");
    Login instance = new Login();
    instance.setUserName("User_");
    assertTrue(instance.checkUsername(), "Valid username should pass");

    instance.setUserName("U_ser");
    assertTrue(instance.checkUsername(), "Another valid username should pass");
}

@org.testng.annotations.Test
public void testCheckUsername_invalidLength() {
    System.out.println("checkUsername_invalidLength");
    Login instance = new Login();
    instance.setUserName("Too_Long");
    assertFalse(instance.checkUsername(), "Username longer than 5 should fail");
}

@org.testng.annotations.Test
public void testCheckUsername_missingUnderscore() {
    System.out.println("checkUsername_missingUnderscore");
    Login instance = new Login();
    instance.setUserName("Short");
    assertFalse(instance.checkUsername(), "Username without underscore should fail");
}
}